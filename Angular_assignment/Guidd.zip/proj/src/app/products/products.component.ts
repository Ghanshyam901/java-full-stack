import { Component } from '@angular/core';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent {
  products = [
    {
      name: "Fire Boult",
      desc: "Fire Boult",
      price: "$65",
      imgSrc: "product_1.jpg",
    },
    {
      name: "Boult Audio Z20",
      desc: "Offers playback time of up to 10 hours for every charge. Carrying case can give 4 additional charges to the earbuds making total play-time of up to 40 Hours.",
      price: "$75",
      imgSrc: "product_2.jpg",
    },
    {
      name: "OnePlus Nord CE 3",
      desc: "Camera: 108 MP Main Camera with EIS; 2MP Depth-Assist Lens and 2MP Macro Lens; Front (Selfie) Camera: 16MP",
      price: "$650",
      imgSrc: "product_3.jpg",
    },
    {
      name: "Apple 2020 MacBook Air Laptop M1 chip",
      desc: "All-Day Battery Life – Go longer than ever with up to 18 hours of battery life.",
      price: "$1855",
      imgSrc: "product_4.jpg",
    },
  ]

  constructor(
    private cart: CartService
  ) { }

  addToCart(product: any) {
    this.cart.addToCart(product);
    window.alert('Product added to Cart');
  }
}
