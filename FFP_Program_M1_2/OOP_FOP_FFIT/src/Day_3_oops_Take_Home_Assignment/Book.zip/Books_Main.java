package Day_3_oops_Take_Home_Assignment;

public class Books_Main {

	public static void main(String[] args) {
		
		MyBook book = new MyBook();
		book.title="hello sk";
		System.out.println(book.getTitle());
		System.out.println(book.setTitle());

	}

}
