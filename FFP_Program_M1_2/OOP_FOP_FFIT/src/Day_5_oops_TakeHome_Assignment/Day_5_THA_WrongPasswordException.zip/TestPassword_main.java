package Day_5_oops_TakeHome_Assignment;

public class TestPassword_main {

	public static void main(String[] args) throws Exception {
		
		Validator v = new Validator();
		String password ="absdddA@";
		System.out.print(v.validatePassword(password));
		
		
	}

}
