package Day_5_oops_Guided_Assignment;


public class AccountManager extends AccountList {

	public boolean checkAccount(long accountnum){
		
		for(int i=0; i<list.size(); i++){
			Account ac = list.get(i);
			if(ac.getAccountNumber() == accountnum){
				return true;
			}
		}
		
		return false;

	}
	
	public double deposit(long accountNo, double amount){
		
		if(amount < 0){
			return 404;
		}
		boolean isaccount = false;
		
		for(int i=0; i<list.size(); i++){
			 Account ac = list.get(i);
			if(ac.getAccountNumber() == accountNo){
				isaccount = true;
				double preAmount = ac.getBalance();
				ac.setBalance(amount+preAmount);
				return ac.getBalance();
				
			}
		}
		if(isaccount == false){
			return 404;
		}
		
		return 404;
		
	}
	
	public double withdraw(long accountNo, double amount){
		
		boolean isaccount = false;
		
		for(int i=0; i<list.size(); i++){
			 Account ac = list.get(i);
			if(ac.getAccountNumber() == accountNo){
				isaccount = true;
				double preAmount = ac.getBalance();
				if(preAmount < amount || amount < 0){
					return 404;
				}else{
					
					preAmount -=amount;
					ac.setBalance(preAmount);
					
					return ac.getBalance();
				}
				
			}	
		}
		
		if(isaccount == false){
			return 404;
		}
		
		
		
		return 404;
		
	}
	
	
	
}
