package Day_3_oops_Guided_Assignment1;

public class Mycalc_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		myCalculator cal = new myCalculator();
		System.out.print(cal.divisorSum(6));
	}

}
