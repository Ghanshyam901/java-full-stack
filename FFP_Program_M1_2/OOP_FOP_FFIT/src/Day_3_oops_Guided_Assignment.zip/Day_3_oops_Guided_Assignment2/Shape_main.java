package Day_3_oops_Guided_Assignment2;

public class Shape_main {

	public static void main(String[] args) {
		
		Triangle t = new Triangle(146.2,40);
		t.printDetails();
		System.out.println("Area = "+ t.getArea());
		
		

	}

}
