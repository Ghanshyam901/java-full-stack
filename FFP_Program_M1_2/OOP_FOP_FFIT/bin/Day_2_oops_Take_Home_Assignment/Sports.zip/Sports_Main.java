package Day_2_oops_Take_Home_Assignment;

public class Sports_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Soccer sc= new Soccer();
		sc.name="Footbal";
		sc.players="11";
		System.out.print(sc.toString());

	}

}
