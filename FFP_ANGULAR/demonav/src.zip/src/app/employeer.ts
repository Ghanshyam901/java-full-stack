export class employeer{
    constructor(
        id:any,
        fistName:any,
        lastName:any,
        email:any,
        dept_id:any
    ){}
}