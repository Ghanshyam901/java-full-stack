package com.example.demo.Game;

public interface GamingConsole {



public void up();

public void left();

public void right();

public void down();






}

