package com.example.demo.Game;


public class Mario implements GamingConsole {
    public void up() {
        System.out.println("Mario jumps up.");
    }
    public void down() {
        System.out.println("Mario comes down.");
    }
    public void left() {
        System.out.println("Mario turns left.");
    }
    public void right() {
        System.out.println("Mario turns right.");
    }
}