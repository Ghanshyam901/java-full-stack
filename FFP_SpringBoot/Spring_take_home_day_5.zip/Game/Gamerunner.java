package com.example.demo.Game;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

public class Gamerunner {
    public static void main(String[] args) {
        GamingConsole game = new Mario();
        game.up();
        game.down();
        game.left();
        game.right();

        game = new SuperMario();
        game.up();
        game.down();
        game.left();
        game.right();
    }
}

