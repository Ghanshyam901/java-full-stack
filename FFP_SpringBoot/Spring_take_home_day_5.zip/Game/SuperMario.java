package com.example.demo.Game;
public class SuperMario implements GamingConsole {
    public void up() {
        System.out.println("SuperMario jumps higher.");
    }
    public void down() {
        System.out.println("SuperMario comes down.");
    }
    public void left() {
        System.out.println("SuperMario turns left.");
    }
    public void right() {
        System.out.println("SuperMario turns right.");
    }
}